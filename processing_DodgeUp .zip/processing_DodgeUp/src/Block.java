import processing.core.PApplet;

public class Block {

    private static PApplet x = Main.processing;
    public static int BlockWidth = 40;
    public static int BlockHeight = 40;
    private int BlockX ;
    private int BlockY;
    private int BlockColor1 ;
    private int BlockColor2 ;
    private int BlockColor3 ;


    public Block(int blockX, int blockY, int blockColor1, int blockColor2, int blockColor3) {
        BlockX = blockX;
        BlockY = blockY;
        BlockColor1 = blockColor1;
        BlockColor2 = blockColor2;
        BlockColor3 = blockColor3;
    }




    public void showObject(){
        x.fill(0,0,0);
        for ( int i = 0 ; i<2000 ; i++){
            Main.blocks.add(new Block( (int) x.random(80) , (int) (-x.random(60 , 120) - Main.blockDistanceY) , (int) x.random(255) , (int) x.random(255) , (int) x.random(255)));
            Main.blocks.add(new Block( (int) x.random(140 , 160) , (int) (-x.random(60 , 120) - Main.blockDistanceY) , (int) x.random(255) , (int) x.random(255) , (int) x.random(255) ));
            Main.blocks.add(new Block( (int) x.random(230 , 270) , (int) (-x.random(60 , 120) - Main.blockDistanceY) , (int) x.random(255) , (int) x.random(255) , (int) x.random(255) ));
            Main.blocks.add(new Block( (int) x.random(320 , 360) , (int) (-x.random(60 , 120) - Main.blockDistanceY) , (int) x.random(255) , (int) x.random(255) , (int) x.random(255) ));

            Main.blockDistanceY += 170;
        }
    }

    public int getBlockX(){
        return BlockX;
    }


    public int getBlockY(){
        return BlockY;
    }


    public static int getBlockWidth() {
        return BlockWidth;
    }


    public void setBlockY(int blockY) {
        BlockY = blockY;
    }

    public int getBlockColor1() {
        return BlockColor1;
    }

    public int getBlockColor2() {
        return BlockColor2;
    }

    public int getBlockColor3() {
        return BlockColor3;
    }
}