import processing.core.PImage;

public class Human {
    public static PImage imgHuman ;


    public static void loadingImage(){
        imgHuman = Main.processing.loadImage("yellowAmongUs.png") ;

    }


    public static void showHuman() {
        Main.processing.image(imgHuman , Main.processing.mouseX , 600 , 30 , 50);
    }

}
