import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;

public class Main extends PApplet {
    public static PApplet processing;

    public static void main(String[] args) {
        PApplet.main("Main" , args);
    }
    public static int blockSpeedY = 5;
    public int headWidth;

    public static int blockDistanceY = 170;
    public static int lives = 3;
    public static ArrayList <Block> blocks = new ArrayList<>();
    public static PImage imgBack ;
    public static PImage imgLost;
    public static float score = 0;


    @Override
    public void setup() {
        processing = this;
        Block block = new Block(0,0,0,0,0);
        block.showObject();
        Human.loadingImage();
        imgBack = loadImage("stars-background.jpeg");
    }

    @Override
    public void settings() {
        size(400 , 700);
    }

    @Override
    public void draw() {
        Human.showHuman();


        image(imgBack , 0,0,400,700);

            headWidth = 20 ;
            headWidth +=3;
            Human.showHuman();

            for (Block c :blocks) {
                showBlock(c.getBlockX() , c.getBlockY() , c.getBlockColor1() , c.getBlockColor2() , c.getBlockColor3());
            }

        fill(251, 255, 0);
        textSize(30);
        text("lives: " + lives, 30 ,50);
        text("score: " + (int)score ,280,50);



        moveBlocks();
            checkCrushed();
            if (lives == 0){
                lost();
            }

        score += 0.1;
    }


    public void moveBlocks(){
        for (Block c :blocks) {
            c.setBlockY(c.getBlockY() + blockSpeedY);
        }
    }


    public void showBlock(int x , int y , int R , int G , int B){
        fill(R,G,B);
        noStroke();
        rect(x,y,Block.BlockWidth ,Block.BlockHeight);
    }

//if human crushed blocks
    public void checkCrushed(){


        for ( int i=0 ; i< blocks.size() ; i++ ) {


            if ( mouseX >= blocks.get(i).getBlockX() && mouseX <= blocks.get(i).getBlockX() + Block.getBlockWidth() && 600 >= blocks.get(i).getBlockY() && 600 <= blocks.get(i).getBlockY() + Block.BlockHeight ){
                blocks.remove(blocks.get(i));
                lives--;
            } else if ( mouseX + 15 >= blocks.get(i).getBlockX() && mouseX + 15 <= blocks.get(i).getBlockX() + Block.getBlockWidth() && 600 >= blocks.get(i).getBlockY() && 600 <= blocks.get(i).getBlockY() + Block.BlockHeight ){
                blocks.remove(blocks.get(i));
                lives--;
            } else if ( mouseX + 30 >= blocks.get(i).getBlockX() && mouseX + 30 <= blocks.get(i).getBlockX() + Block.getBlockWidth() && 600 >= blocks.get(i).getBlockY() && 600 <= blocks.get(i).getBlockY() + Block.BlockHeight ) {
                blocks.remove(blocks.get(i));
                lives--;
            }
        }
    }




    public void lost(){

        background(0);
        imgLost = loadImage("DeadAmongUs.png");
        image(imgLost ,50,100, 300 , 600);


        fill(255);

//      text score:
        textSize(50);
        text("YOUR SCORE:" + (int)score, 40 , 70);

//      text lost:
        textSize(50);
        text("YOU DIED:)))" , 40 , 130);

        stop();

    }
}